# Paper

A typora theme using latex fonts to be used in academic work. See a demo of a generated pdf [here](demo/demo.pdf).



![image_1](images/image_1.png)

![image_2](images/image_2.png)

![image_3](images/image_3.png)